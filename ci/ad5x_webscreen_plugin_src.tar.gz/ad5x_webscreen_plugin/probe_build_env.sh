#!/bin/sh
set +e
echo "=== AD5X WebScreen build environment ==="
uname -a
printf 'arch: '; uname -m
printf 'cc: '; command -v cc || true
printf 'gcc: '; command -v gcc || true
printf 'make: '; command -v make || true
printf 'jpeglib.h: '; [ -r /usr/include/jpeglib.h ] && echo yes || echo no
printf 'libjpeg candidates:\n'
find /lib /usr/lib /usr/local/lib /usr/prog /opt -name 'libjpeg.so*' 2>/dev/null | head -n 30
printf 'fb0: '; ls -l /dev/fb0 2>/dev/null || true
printf 'touch candidates:\n'
for f in /sys/class/input/event*/device/name; do [ -r "$f" ] && printf '%s: %s\n' "$f" "$(cat "$f")"; done

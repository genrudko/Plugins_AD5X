#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
mkdir -p "$ROOT/build"
cc -std=c11 -Wall -Wextra -Werror -O2 -I"$ROOT/src" \
  "$ROOT/tests/test_core.c" "$ROOT/src/webscreen_core.c" \
  -o "$ROOT/build/test_core"
"$ROOT/build/test_core"
make -C "$ROOT" clean all
python3 "$ROOT/tests/test_integration.py"

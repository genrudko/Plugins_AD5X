#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
[ -f "$ROOT/ad5x_webscreen_plugin.cfg" ]
[ -f "$ROOT/ad5x_webscreen_plugin.conf.example" ]
grep -q '/opt/config/mod_data/plugins/ad5x_webscreen_plugin/runtime.sh' "$ROOT/ad5x_webscreen_plugin.cfg"
grep -q 'PORT=8011' "$ROOT/ad5x_webscreen_plugin.conf.example"
grep -q 'TOUCH_ALLOWED=0' "$ROOT/ad5x_webscreen_plugin.conf.example"
! grep -R '/opt/config/mod_data/plugins/ad5x_webscreen/runtime.sh' "$ROOT" --exclude='test_packaging.sh' >/dev/null 2>&1
! grep -R '/opt/config/mod_data/ad5x_webscreen.conf' "$ROOT" --exclude='test_packaging.sh' >/dev/null 2>&1
! grep -q 'delayed_gcode' "$ROOT/ad5x_webscreen_plugin.cfg"
echo 'test_packaging: ok'

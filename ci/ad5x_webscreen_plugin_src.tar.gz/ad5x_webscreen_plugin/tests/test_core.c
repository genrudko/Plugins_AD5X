#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "webscreen_core.h"

static void test_rotated_source_offset(void) {
    /* 480x800 portrait framebuffer rotated 90 degrees clockwise => 800x480 web image. */
    size_t off = ad5x_source_offset_for_output(0, 0, 480, 800, 4);
    assert(off == ((size_t)799 * 480 + 0) * 4);

    off = ad5x_source_offset_for_output(799, 479, 480, 800, 4);
    assert(off == ((size_t)0 * 480 + 479) * 4);

    off = ad5x_source_offset_for_output(400, 240, 480, 800, 4);
    assert(off == ((size_t)399 * 480 + 240) * 4);
}

static void test_scale_axis(void) {
    assert(ad5x_scale_axis(0, 799, 0, 799) == 0);
    assert(ad5x_scale_axis(799, 799, 0, 799) == 799);
    assert(ad5x_scale_axis(0, 799, 100, 900) == 100);
    assert(ad5x_scale_axis(799, 799, 100, 900) == 900);
    assert(ad5x_scale_axis(400, 799, 0, 799) == 400);
}

static void test_query_param(void) {
    char out[32];
    assert(ad5x_query_param("/touch?action=move&x=321&y=44", "action", out, sizeof(out)) == 1);
    assert(strcmp(out, "move") == 0);
    assert(ad5x_query_param("/touch?action=move&x=321&y=44", "x", out, sizeof(out)) == 1);
    assert(strcmp(out, "321") == 0);
    assert(ad5x_query_param("/touch?action=move&x=321&y=44", "missing", out, sizeof(out)) == 0);
}

static void test_device_name_preference(void) {
    assert(ad5x_touch_name_rank("TSC2007 Touchscreen") == 2);
    assert(ad5x_touch_name_rank("Generic Touchscreen") == 1);
    assert(ad5x_touch_name_rank("gpio-keys") == 0);
}


static void test_fps_from_timestamps(void) {
    double t[] = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};
    double fps = ad5x_fps_from_timestamps(t, 10);
    assert(fps > 9.99 && fps < 10.01);
    assert(ad5x_fps_from_timestamps(t, 1) == 0.0);
}

int main(void) {
    test_rotated_source_offset();
    test_scale_axis();
    test_query_param();
    test_device_name_preference();
    test_fps_from_timestamps();
    puts("test_core: ok");
    return 0;
}

#!/usr/bin/env python3
import http.client
import json
import os
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import time

try:
    from PIL import Image
except Exception as exc:
    print(f"SKIP: Pillow unavailable: {exc}")
    raise SystemExit(0)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, "build", "ad5x_webscreen_plugin")
W, H = 480, 800


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def make_fb(path):
    # BGRA portrait image with distinctive corners after rotation.
    with open(path, "wb") as f:
        for y in range(H):
            for x in range(W):
                b = x & 0xFF
                g = y & 0xFF
                r = (x + y) & 0xFF
                f.write(bytes((b, g, r, 255)))


def wait_http(port):
    deadline = time.time() + 5
    while time.time() < deadline:
        try:
            c = http.client.HTTPConnection("127.0.0.1", port, timeout=0.5)
            c.request("GET", "/health")
            r = c.getresponse()
            body = r.read()
            if r.status == 200 and body == b"ok\n":
                return
        except OSError:
            time.sleep(0.05)
    raise RuntimeError("daemon did not become ready")


def get(port, path):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    c.request("GET", path)
    r = c.getresponse()
    body = r.read()
    return r, body


def main():
    if not os.path.exists(BIN):
        raise AssertionError(f"missing daemon binary: {BIN}")
    port = free_port()
    with tempfile.TemporaryDirectory() as td:
        fb = os.path.join(td, "fb0")
        make_fb(fb)
        proc = subprocess.Popen([
            BIN, "--bind", "127.0.0.1", "--port", str(port),
            "--fb", fb, "--fps", "10", "--quality", "70", "--no-touch"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            wait_http(port)
            r, body = get(port, "/status")
            assert r.status == 200
            status = json.loads(body)
            assert status["target_fps"] == 10
            assert status["stream_clients"] == 0
            assert status["encoded_frames"] == 0, status

            r, body = get(port, "/snapshot")
            assert r.status == 200
            assert r.getheader("Content-Type") == "image/jpeg"
            jpg = os.path.join(td, "snap.jpg")
            with open(jpg, "wb") as f:
                f.write(body)
            im = Image.open(jpg)
            assert im.size == (800, 480), im.size

            # Snapshot should not turn on the continuous producer.
            r, body = get(port, "/status")
            status = json.loads(body)
            assert status["stream_clients"] == 0
            assert status["encoded_frames"] == 0, status

            # A stream client must cause exactly one central producer to wake.
            s = socket.create_connection(("127.0.0.1", port), timeout=2)
            s.sendall(b"GET /stream HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
            data = b""
            deadline = time.time() + 2
            while b"Content-Type: image/jpeg" not in data and time.time() < deadline:
                data += s.recv(65536)
            assert b"multipart/x-mixed-replace" in data
            assert b"Content-Type: image/jpeg" in data
            s.close()
            time.sleep(0.2)
            r, body = get(port, "/status")
            status = json.loads(body)
            assert status["encoded_frames"] >= 1, status
        finally:
            proc.send_signal(signal.SIGTERM)
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            if proc.returncode not in (0, -signal.SIGTERM):
                err = proc.stderr.read().decode("utf-8", "replace")
                raise RuntimeError(f"daemon exit {proc.returncode}: {err}")
    print("test_integration: ok")

if __name__ == "__main__":
    main()

#!/bin/sh
set -eu
SELF_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BIN="$SELF_DIR/bin/ad5x_webscreen_plugin"
CONF="/opt/config/mod_data/ad5x_webscreen_plugin.conf"

if [ ! -f "$BIN" ]; then
    echo "ERROR: prebuilt MIPS binary missing: $BIN"
    exit 1
fi
chmod 755 "$BIN" "$SELF_DIR/runtime.sh" "$SELF_DIR/uninstall.sh" "$SELF_DIR/probe_build_env.sh"

# Fail closed if someone accidentally installs an x86 or wrong-endian package.
if command -v readelf >/dev/null 2>&1; then
    hdr="$(readelf -h "$BIN" 2>/dev/null || true)"
    attrs="$(readelf -A "$BIN" 2>/dev/null || true)"
    echo "$hdr" | grep -q 'Class:.*ELF32' || { echo 'ERROR: binary is not ELF32'; exit 1; }
    echo "$hdr" | grep -q 'Data:.*little endian' || { echo 'ERROR: binary is not little-endian'; exit 1; }
    echo "$hdr" | grep -q 'Machine:.*MIPS' || { echo 'ERROR: binary is not MIPS'; exit 1; }
    echo "$hdr" | grep -q 'Flags:.*nan2008.*o32.*mips32r2' || { echo 'ERROR: MIPS ABI flags do not match AD5X'; exit 1; }
    echo "$attrs" | grep -q 'Hard float (32-bit CPU, 64-bit FPU)' || { echo 'ERROR: FP ABI does not match AD5X'; exit 1; }
fi

if [ ! -e "$CONF" ]; then
    cp "$SELF_DIR/ad5x_webscreen_plugin.conf.example" "$CONF"
    chmod 644 "$CONF"
    echo "Created $CONF"
else
    echo "Keeping existing $CONF"
fi

echo "AD5X WebScreen C installed in read-only mode."
echo "Service is NOT auto-started. Run runtime.sh start when ready."

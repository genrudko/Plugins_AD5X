#ifndef AD5X_FRAMEBUFFER_H
#define AD5X_FRAMEBUFFER_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    int fd;
    size_t size;
    uint8_t *mapped;
    uint8_t *copy;
    int mapped_ok;
} ad5x_framebuffer;

int ad5x_framebuffer_open(ad5x_framebuffer *fb, const char *path, size_t size);
int ad5x_framebuffer_capture(ad5x_framebuffer *fb);
void ad5x_framebuffer_close(ad5x_framebuffer *fb);

#endif

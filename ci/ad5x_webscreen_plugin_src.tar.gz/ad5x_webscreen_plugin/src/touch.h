#ifndef AD5X_TOUCH_H
#define AD5X_TOUCH_H

#include <pthread.h>
#include <stddef.h>
#include <stdint.h>

typedef struct {
    pthread_mutex_t mu;
    int allowed;
    int armed;
    int fd;
    int down;
    int abs_x_min;
    int abs_x_max;
    int abs_y_min;
    int abs_y_max;
    long long last_event_ms;
    char device[256];
    char name[256];
} ad5x_touch;

int ad5x_touch_init(ad5x_touch *t, int allowed, const char *sysfs_root);
void ad5x_touch_destroy(ad5x_touch *t);
int ad5x_touch_set_armed(ad5x_touch *t, int armed);
int ad5x_touch_action(ad5x_touch *t, const char *action, int x, int y);
void ad5x_touch_failsafe_tick(ad5x_touch *t, long long now_ms, int timeout_ms);
void ad5x_touch_status(ad5x_touch *t, int *available, int *armed, int *down,
                       char *device, size_t device_size, char *name, size_t name_size);

#endif

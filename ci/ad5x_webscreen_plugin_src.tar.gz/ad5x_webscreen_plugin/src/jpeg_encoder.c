#include "jpeg_encoder.h"
#include "webscreen_core.h"

#include <stdio.h>
#include <jpeglib.h>
#include <setjmp.h>
#include <stdlib.h>
#include <string.h>

struct ad5x_jpeg_error {
    struct jpeg_error_mgr pub;
    jmp_buf jump;
};

struct ad5x_dest {
    struct jpeg_destination_mgr pub;
    ad5x_jpeg_encoder *enc;
};

static void ad5x_jpeg_error_exit(j_common_ptr cinfo) {
    struct ad5x_jpeg_error *err = (struct ad5x_jpeg_error *)cinfo->err;
    longjmp(err->jump, 1);
}

static void dest_init(j_compress_ptr cinfo) {
    struct ad5x_dest *dest = (struct ad5x_dest *)cinfo->dest;
    ad5x_jpeg_encoder *enc = dest->enc;
    if (!enc->out) {
        enc->out_cap = 256 * 1024;
        enc->out = malloc(enc->out_cap);
    }
    dest->pub.next_output_byte = enc->out;
    dest->pub.free_in_buffer = enc->out ? enc->out_cap : 0;
    enc->out_len = 0;
}

static boolean dest_empty(j_compress_ptr cinfo) {
    struct ad5x_dest *dest = (struct ad5x_dest *)cinfo->dest;
    ad5x_jpeg_encoder *enc = dest->enc;
    size_t old_cap = enc->out_cap;
    size_t new_cap = old_cap ? old_cap * 2 : 256 * 1024;
    uint8_t *p = realloc(enc->out, new_cap);
    if (!p) return FALSE;
    enc->out = p;
    enc->out_cap = new_cap;
    dest->pub.next_output_byte = enc->out + old_cap;
    dest->pub.free_in_buffer = new_cap - old_cap;
    return TRUE;
}

static void dest_term(j_compress_ptr cinfo) {
    struct ad5x_dest *dest = (struct ad5x_dest *)cinfo->dest;
    ad5x_jpeg_encoder *enc = dest->enc;
    enc->out_len = enc->out_cap - dest->pub.free_in_buffer;
}

int ad5x_jpeg_encoder_init(ad5x_jpeg_encoder *enc, int width, int height, int quality) {
    if (!enc || width <= 0 || height <= 0) return -1;
    memset(enc, 0, sizeof(*enc));
    enc->width = width;
    enc->height = height;
    enc->quality = quality < 1 ? 1 : (quality > 95 ? 95 : quality);
    enc->row = malloc((size_t)width * 3);
    enc->cinfo = calloc(1, sizeof(struct jpeg_compress_struct));
    enc->jerr = calloc(1, sizeof(struct ad5x_jpeg_error));
    if (!enc->row || !enc->cinfo || !enc->jerr) {
        ad5x_jpeg_encoder_destroy(enc);
        return -1;
    }

    struct jpeg_compress_struct *cinfo = enc->cinfo;
    struct ad5x_jpeg_error *jerr = enc->jerr;
    cinfo->err = jpeg_std_error(&jerr->pub);
    jerr->pub.error_exit = ad5x_jpeg_error_exit;
    if (setjmp(jerr->jump)) {
        ad5x_jpeg_encoder_destroy(enc);
        return -1;
    }
    jpeg_create_compress(cinfo);

    struct ad5x_dest *dest = (struct ad5x_dest *)(*cinfo->mem->alloc_small)(
        (j_common_ptr)cinfo, JPOOL_PERMANENT, sizeof(struct ad5x_dest));
    dest->enc = enc;
    dest->pub.init_destination = dest_init;
    dest->pub.empty_output_buffer = dest_empty;
    dest->pub.term_destination = dest_term;
    cinfo->dest = (struct jpeg_destination_mgr *)dest;
    return 0;
}

int ad5x_jpeg_encode_rotated_bgra(ad5x_jpeg_encoder *enc,
                                  const uint8_t *bgra,
                                  int src_w, int src_h,
                                  const uint8_t **jpeg_out,
                                  size_t *jpeg_len) {
    if (!enc || !enc->cinfo || !enc->jerr || !bgra || !jpeg_out || !jpeg_len) return -1;
    if (enc->width != src_h || enc->height != src_w) return -1;

    struct jpeg_compress_struct *cinfo = enc->cinfo;
    struct ad5x_jpeg_error *jerr = enc->jerr;
    if (setjmp(jerr->jump)) {
        jpeg_abort_compress(cinfo);
        return -1;
    }

    cinfo->image_width = enc->width;
    cinfo->image_height = enc->height;
    cinfo->input_components = 3;
    cinfo->in_color_space = JCS_RGB;
    jpeg_set_defaults(cinfo);
    cinfo->dct_method = JDCT_IFAST;
    cinfo->optimize_coding = FALSE;
    jpeg_set_quality(cinfo, enc->quality, TRUE);
    /* Explicit 4:2:0 chroma subsampling: lower bandwidth and CPU than 4:4:4. */
    cinfo->comp_info[0].h_samp_factor = 2;
    cinfo->comp_info[0].v_samp_factor = 2;
    cinfo->comp_info[1].h_samp_factor = 1;
    cinfo->comp_info[1].v_samp_factor = 1;
    cinfo->comp_info[2].h_samp_factor = 1;
    cinfo->comp_info[2].v_samp_factor = 1;

    jpeg_start_compress(cinfo, TRUE);
    while (cinfo->next_scanline < cinfo->image_height) {
        const int y = (int)cinfo->next_scanline;
        /* ROTATE_270: out(x,y) <- src(y, src_h-1-x).
         * Walk one source column backwards to avoid a helper call and
         * multiply for every pixel in the 10 FPS hot path. */
        const uint8_t *src = bgra + (((size_t)src_h - 1u) * (size_t)src_w + (size_t)y) * 4u;
        for (int x = 0; x < enc->width; ++x, src -= (size_t)src_w * 4u) {
            uint8_t *dst = enc->row + (size_t)x * 3u;
            dst[0] = src[2];
            dst[1] = src[1];
            dst[2] = src[0];
        }
        JSAMPROW row = enc->row;
        jpeg_write_scanlines(cinfo, &row, 1);
    }
    jpeg_finish_compress(cinfo);
    if (!enc->out || enc->out_len == 0) return -1;
    *jpeg_out = enc->out;
    *jpeg_len = enc->out_len;
    return 0;
}

void ad5x_jpeg_encoder_destroy(ad5x_jpeg_encoder *enc) {
    if (!enc) return;
    if (enc->cinfo) {
        struct jpeg_compress_struct *cinfo = enc->cinfo;
        if (cinfo->mem) jpeg_destroy_compress(cinfo);
    }
    free(enc->row);
    free(enc->out);
    free(enc->cinfo);
    free(enc->jerr);
    memset(enc, 0, sizeof(*enc));
}
